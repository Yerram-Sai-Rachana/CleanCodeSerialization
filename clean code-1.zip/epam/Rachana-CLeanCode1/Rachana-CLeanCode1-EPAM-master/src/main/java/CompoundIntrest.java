public interface CompoundIntrest {
    Double comPoundInterest();
}
